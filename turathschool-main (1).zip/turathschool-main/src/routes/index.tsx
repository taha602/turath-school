import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "مدرسة التراث الكربلائي الحسيني" },
      { name: "description", content: "منصة مدرسة التراث الكربلائي الحسيني للدروس والإعلانات والحضور." },
      { property: "og:title", content: "مدرسة التراث الكربلائي الحسيني" },
      { property: "og:description", content: "منصة المدرسة للدروس والإعلانات والحضور مع إشعارات فورية." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

function Index() {
  useEffect(() => {
    window.location.replace("/school/index.html");
  }, []);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background text-foreground" dir="rtl">
      جارٍ فتح المدرسة...
    </div>
  );
}
