import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { buildPushPayload } from "@block65/webcrypto-web-push";

// The school app's own (external) backend — public URL + publishable key.
const SCHOOL_URL = "https://cdsyuaplkalohqxsvoxs.supabase.co";
const SCHOOL_KEY = "sb_publishable_E_QKhnQWZEXbRYcCkmL5uw_9Rceu07S";
export const VAPID_PUBLIC_KEY =
  "BCtTRjntrkUMN0B62rumKU5yDuuSdAKyRNxUX-5uKCKSJR4MzwyJ0dIm5DhshI-Cb-DIkf9U2FcjvETukv8Oqww";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "content-type",
};
const json = (b: unknown, status = 200) => Response.json(b, { status, headers: cors });

const Body = z.discriminatedUnion("action", [
  z.object({
    action: z.literal("subscribe"),
    token: z.string().min(10).max(4000),
    subscription: z.object({
      endpoint: z.string().url().startsWith("https://").max(1000),
      keys: z.object({ p256dh: z.string().min(10).max(300), auth: z.string().min(4).max(100) }),
    }),
  }),
  z.object({
    action: z.literal("notify"),
    token: z.string().min(10).max(4000),
    table: z.enum(["announcements", "lessons", "warnings", "student_notes", "leave_requests"]),
    op: z.enum(["insert", "update"]),
    id: z.string().uuid().optional(),
  }),
]);

type Profile = { id: string; role: string; full_name?: string };

async function school(path: string, token: string) {
  const r = await fetch(SCHOOL_URL + path, {
    headers: { apikey: SCHOOL_KEY, Authorization: `Bearer ${token}` },
  });
  if (!r.ok) return null;
  return r.json();
}

async function verify(token: string): Promise<Profile | null> {
  const user = await school("/auth/v1/user", token);
  if (!user?.id) return null;
  const rows = await school(`/rest/v1/profiles?id=eq.${user.id}&select=id,role,full_name`, token);
  return Array.isArray(rows) && rows[0] ? rows[0] : null;
}

const trim = (s: unknown, n = 160) => String(s ?? "").slice(0, n);

export const Route = createFileRoute("/api/public/push")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: cors }),
      POST: async ({ request }) => {
        const parsed = Body.safeParse(await request.json().catch(() => null));
        if (!parsed.success) return json({ error: "bad request" }, 400);
        const body = parsed.data;

        const me = await verify(body.token);
        if (!me) return json({ error: "unauthorized" }, 401);

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        if (body.action === "subscribe") {
          const { error } = await supabaseAdmin.from("push_devices").upsert(
            {
              school_user_id: me.id,
              role: me.role,
              endpoint: body.subscription.endpoint,
              p256dh: body.subscription.keys.p256dh,
              auth: body.subscription.keys.auth,
            },
            { onConflict: "endpoint" },
          );
          if (error) return json({ error: error.message }, 500);
          return json({ ok: true });
        }

        // notify: read the real row with the sender's own permissions
        const t = body.table;
        const q = body.id
          ? `/rest/v1/${t}?id=eq.${body.id}&select=*`
          : `/rest/v1/${t}?select=*&order=created_at.desc&limit=1`;
        const rows = await school(q, body.token);
        const row = Array.isArray(rows) ? rows[0] : null;
        if (!row) return json({ error: "not found" }, 404);
        if (body.op === "insert" && Date.now() - new Date(row.created_at).getTime() > 5 * 60_000)
          return json({ ok: true, skipped: "old" });

        const staff = me.role === "admin" || me.role === "teacher";
        let title = "";
        let text = "";
        let audience: { all?: true; users?: string[]; roles?: string[] } = {};

        if (t === "announcements" && body.op === "insert" && staff) {
          title = "📢 إعلان جديد: " + trim(row.title, 80);
          text = trim(row.content);
          audience = { all: true };
        } else if (t === "lessons" && body.op === "insert" && staff) {
          title = "📚 درس جديد: " + trim(row.title, 80);
          text = trim(row.content);
          audience = { all: true };
        } else if (t === "warnings" && body.op === "insert" && staff) {
          title = "⚠️ تم تسجيل إنذار عليك";
          text = trim(row.reason);
          audience = { users: [row.student_id] };
        } else if (t === "student_notes" && body.op === "insert" && staff) {
          title = "📝 ملاحظة جديدة من الأستاذ";
          text = trim(row.content);
          audience = { users: [row.student_id] };
        } else if (t === "leave_requests" && body.op === "insert") {
          title = "🗓️ طلب إجازة جديد" + (me.full_name ? " — " + trim(me.full_name, 60) : "");
          text = trim(row.reason) + (row.start_date ? `\nمن ${row.start_date} إلى ${row.end_date || row.start_date}` : "");
          audience = { roles: ["admin", "teacher"] };
        } else if (t === "leave_requests" && body.op === "update" && staff && ["approved", "rejected"].includes(row.status)) {
          title = row.status === "approved" ? "✅ تمت الموافقة على طلب إجازتك" : "❌ تم رفض طلب إجازتك";
          text = row.start_date ? `من ${row.start_date} إلى ${row.end_date || row.start_date}` : "";
          audience = { users: [row.student_id] };
        } else {
          return json({ ok: true, skipped: "no audience" });
        }

        let dq = supabaseAdmin.from("push_devices").select("id,endpoint,p256dh,auth,school_user_id").neq("school_user_id", me.id);
        if (audience.users) dq = dq.in("school_user_id", audience.users.filter(Boolean));
        if (audience.roles) dq = dq.in("role", audience.roles);
        const { data: devices } = await dq.limit(2000);

        const privateKey = process.env["VAPID_PRIVATE_KEY"];
        if (!privateKey) return json({ error: "push not configured" }, 500);
        const vapid = { subject: "mailto:admin@turath-school.app", publicKey: VAPID_PUBLIC_KEY, privateKey };
        const payload = JSON.stringify({ title, body: text, url: "/school/index.html", tag: `${t}:${row.id}` });

        const dead: string[] = [];
        let sent = 0;
        await Promise.all(
          (devices ?? []).map(async (d) => {
            try {
              const req = await buildPushPayload(
                { data: payload, options: { ttl: 86400, urgency: "high" } },
                { endpoint: d.endpoint, expirationTime: null, keys: { p256dh: d.p256dh, auth: d.auth } },
                vapid,
              );
              const r = await fetch(d.endpoint, req);
              if (r.status === 404 || r.status === 410) dead.push(d.id);
              else if (r.ok) sent++;
              else console.error("push failed", r.status, await r.text());
            } catch (e) {
              console.error("push error", e);
            }
          }),
        );
        if (dead.length) await supabaseAdmin.from("push_devices").delete().in("id", dead);
        return json({ ok: true, sent, removed: dead.length });
      },
    },
  },
});
